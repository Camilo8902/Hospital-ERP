import BillingClient from './BillingClient';

export default function BillingPage() {
  return <BillingClient />;
}
