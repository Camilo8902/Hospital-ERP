export default function PrintLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
