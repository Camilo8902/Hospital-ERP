'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Users,
  Calendar,
  FileText,
  Settings,
  ChevronLeft,
  Menu,
  LogOut,
  UserCog,
  Building2,
  ChevronDown,
  ChevronRight,
  Loader2,
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useMobileMenu } from './MobileMenuContext';
import { getDepartmentsForSidebar, DepartmentWithAccess } from '@/lib/actions/departments';
import { 
  Activity, 
  Scan, 
  Stethoscope, 
  Pill, 
  FlaskConical, 
  Baby, 
  Siren, 
  Heart, 
  Building 
} from 'lucide-react';

interface SidebarProps {
  userRole: string;
  userName: string;
}

// Iconos estáticos para módulos institucionales
const staticModules = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
    roles: ['admin', 'doctor', 'nurse', 'reception', 'pharmacy', 'lab'],
  },
  {
    name: 'Pacientes',
    href: '/dashboard/patients',
    icon: Users,
    roles: ['admin', 'doctor', 'nurse', 'reception'],
  },
  {
    name: 'Citas',
    href: '/dashboard/appointments',
    icon: Calendar,
    roles: ['admin', 'doctor', 'nurse', 'reception'],
  },
  {
    name: 'Usuarios',
    href: '/dashboard/users',
    icon: UserCog,
    roles: ['admin'],
  },
  {
    name: 'Configuración',
    href: '/dashboard/settings',
    icon: Settings,
    roles: ['admin'],
  },
];

// Iconos para departamentos
const departmentIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Activity,
  Scan,
  Stethoscope,
  Pill,
  FlaskConical,
  Baby,
  Siren,
  Heart,
  Building,
  Building2,
};

export default function Sidebar({ userRole, userName }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [departments, setDepartments] = useState<DepartmentWithAccess[]>([]);
  const [isLoadingDepartments, setIsLoadingDepartments] = useState(true);
  const [departmentsExpanded, setDepartmentsExpanded] = useState(false);
  const pathname = usePathname();
  const supabase = createClient();
  const { isMobileMenuOpen, closeMobileMenu } = useMobileMenu();

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    const loadDepartments = async () => {
      try {
        const depts = await getDepartmentsForSidebar(userRole);
        setDepartments(depts);
      } catch (error) {
        console.error('Error loading departments:', error);
      } finally {
        setIsLoadingDepartments(false);
      }
    };

    loadDepartments();
  }, [userRole]);

  // Filtrar módulos estáticos por rol
  const visibleStaticModules = staticModules.filter((item) =>
    item.roles.includes(userRole as string)
  );

  const handleLogout = async () => {
    if (isLoggingOut) return;
    setIsLoggingOut(true);
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Error al cerrar sesion:', error.message);
        setIsLoggingOut(false);
        return;
      }
      window.location.href = '/login';
    } catch (error) {
      console.error('Error inesperado al cerrar sesion:', error);
      setIsLoggingOut(false);
    }
  };

  const handleNavigation = () => {
    if (isMobile) {
      closeMobileMenu();
    }
  };

  const renderNavItem = (
    item: { name: string; href: string; icon: React.ComponentType<{ className?: string }> },
    isActive: boolean,
    isCollapsed: boolean
  ) => (
    <Link
      key={item.name}
      href={item.href}
      onClick={handleNavigation}
      className={cn(
        'sidebar-link',
        isActive && 'sidebar-link-active',
        isCollapsed && 'justify-center px-2 lg:px-1'
      )}
      title={isCollapsed ? item.name : undefined}
    >
      <item.icon className={cn('w-5 h-5 flex-shrink-0', isActive && 'text-primary-600')} />
      {!isCollapsed && <span className="truncate">{item.name}</span>}
    </Link>
  );

  const renderDepartmentItem = (dept: DepartmentWithAccess, isCollapsed: boolean) => {
    const IconComponent = departmentIcons[dept.icon || ''] || Building2;
    const isActive = pathname === dept.href || pathname.startsWith(dept.href + '/');

    return (
      <Link
        key={dept.id}
        href={dept.href}
        onClick={handleNavigation}
        className={cn(
          'sidebar-link',
          isActive && 'sidebar-link-active',
          isCollapsed && 'justify-center px-2 lg:px-1'
        )}
        title={isCollapsed ? dept.name : undefined}
      >
        <IconComponent className={cn('w-5 h-5 flex-shrink-0', isActive && 'text-primary-600')} />
        {!isCollapsed && <span className="truncate">{dept.name}</span>}
      </Link>
    );
  };

  const desktopSidebar = (
    <aside
      className={cn(
        'hidden lg:flex flex-col fixed inset-y-0 left-0 z-50 bg-white border-r border-gray-200 transition-all duration-300',
        collapsed ? 'w-16' : 'w-64'
      )}
    >
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
        {!collapsed && (
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </div>
            <span className="font-bold text-gray-900">MediCore</span>
          </Link>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          aria-label={collapsed ? 'Expandir menú' : 'Contraer menú'}
        >
          {collapsed ? (
            <Menu className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronLeft className={cn('w-5 h-5 text-gray-600 transition-transform', collapsed && 'rotate-180')} />
          )}
        </button>
      </div>

      <nav className="flex-1 p-3 space-y-1 overflow-y-auto scrollbar-thin">
        {/* Módulos estáticos */}
        {visibleStaticModules.map((item) =>
          renderNavItem(item, pathname === item.href || pathname.startsWith(item.href + '/'), collapsed)
        )}

        {/* Separador si hay módulos estáticos y departamentos */}
        {visibleStaticModules.length > 0 && departments.length > 0 && (
          <div className="my-3 border-t border-gray-200" />
        )}

        {/* Sección de Departamentos */}
        {departments.length > 0 && (
          <>
            {!collapsed ? (
              <div className="space-y-1">
                <button
                  onClick={() => setDepartmentsExpanded(!departmentsExpanded)}
                  className={cn(
                    'w-full flex items-center justify-between px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider hover:bg-gray-50 rounded-lg transition-colors',
                    departmentsExpanded && 'bg-gray-50'
                  )}
                >
                  <span>Departamentos</span>
                  {departmentsExpanded ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>
                {departmentsExpanded && (
                  <div className="space-y-1 ml-1">
                    {isLoadingDepartments ? (
                      <div className="flex items-center justify-center py-3">
                        <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                      </div>
                    ) : (
                      departments.map((dept) => renderDepartmentItem(dept, collapsed))
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-1">
                {isLoadingDepartments ? (
                  <div className="flex items-center justify-center py-2">
                    <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                  </div>
                ) : (
                  departments.map((dept) => renderDepartmentItem(dept, collapsed))
                )}
              </div>
            )}
          </>
        )}
      </nav>

      <div className="p-3 border-t border-gray-200">
        <button
          onClick={handleLogout}
          className={cn(
            'sidebar-link w-full text-red-600 hover:text-red-700 hover:bg-red-50',
            collapsed && 'justify-center px-2 lg:px-1'
          )}
          title={collapsed ? 'Cerrar sesión' : undefined}
        >
          <LogOut className="w-5 h-5 flex-shrink-0" />
          {!collapsed && <span className="truncate">Cerrar Sesión</span>}
        </button>
      </div>
    </aside>
  );

  const mobileDrawer = (
    <>
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={closeMobileMenu}
          aria-hidden="true"
        />
      )}
      <div
        className={cn(
          'fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-gray-200 lg:hidden transform transition-transform duration-300 ease-in-out',
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
          <Link href="/dashboard" className="flex items-center gap-2" onClick={handleNavigation}>
            <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                />
              </svg>
            </div>
            <span className="font-bold text-gray-900">MediCore</span>
          </Link>
          <button
            onClick={closeMobileMenu}
            className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            aria-label="Cerrar menú"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </button>
        </div>
        <div className="px-4 py-3 border-b border-gray-100 bg-gray-50">
          <p className="text-sm font-medium text-gray-900">{userName}</p>
          <p className="text-xs text-gray-500 capitalize">{userRole}</p>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* Módulos estáticos */}
          <div className="p-3 space-y-1">
            {visibleStaticModules.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={handleNavigation}
                  className={cn('sidebar-link', isActive && 'sidebar-link-active')}
                >
                  <item.icon className={cn('w-5 h-5 flex-shrink-0', isActive && 'text-primary-600')} />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </div>

          {/* Separador */}
          {visibleStaticModules.length > 0 && departments.length > 0 && (
            <div className="mx-3 border-t border-gray-200" />
          )}

          {/* Departamentos */}
          <div className="p-3 space-y-1">
            <button
              onClick={() => setDepartmentsExpanded(!departmentsExpanded)}
              className={cn(
                'w-full flex items-center justify-between px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider hover:bg-gray-50 rounded-lg transition-colors',
                departmentsExpanded && 'bg-gray-50'
              )}
            >
              <span>Departamentos</span>
              {departmentsExpanded ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </button>

            {isLoadingDepartments ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="w-6 h-6 text-gray-400 animate-spin" />
              </div>
            ) : departmentsExpanded ? (
              <div className="space-y-1">
                {departments.map((dept) => {
                  const IconComponent = departmentIcons[dept.icon || ''] || Building2;
                  const isActive = pathname === dept.href || pathname.startsWith(dept.href + '/');
                  return (
                    <Link
                      key={dept.id}
                      href={dept.href}
                      onClick={handleNavigation}
                      className={cn('sidebar-link', isActive && 'sidebar-link-active')}
                    >
                      <IconComponent className={cn('w-5 h-5 flex-shrink-0', isActive && 'text-primary-600')} />
                      <span>{dept.name}</span>
                    </Link>
                  );
                })}
              </div>
            ) : null}
          </div>
        </div>

        <div className="p-3 border-t border-gray-200">
          <button
            onClick={handleLogout}
            className="sidebar-link w-full text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <LogOut className="w-5 h-5 flex-shrink-0" />
            <span>Cerrar Sesión</span>
          </button>
        </div>
      </div>
    </>
  );

  return <>{desktopSidebar}{mobileDrawer}</>;
}
